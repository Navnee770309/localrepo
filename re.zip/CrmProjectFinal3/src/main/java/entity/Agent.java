package entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.List;

@Entity
@Table(name = "agents")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Agent {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String name; // Agent's name

    @Column(nullable = false, unique = true)
    private String email; // Agent's email


    @OneToMany(mappedBy = "assignedAgent", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private List<Ticket> assignedTickets;

    @Transient 
    public int getCurrentAssignedTicketsCount() {
        return assignedTickets != null ? assignedTickets.size() : 0;
    }
}