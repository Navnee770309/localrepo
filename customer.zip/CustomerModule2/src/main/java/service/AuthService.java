package service;

import payload.LoginDto;
import payload.RegisterDto;
public interface AuthService {
    String login(LoginDto loginDto);

    String register(RegisterDto registerDto);
}
