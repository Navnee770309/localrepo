package controller; // Adjust package name if different

import payload.AgentDto;
import service.AgentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.util.List;

/**
 * REST Controller for Agent management within the Ticketing Module.
 * Exposes API endpoints for creating, retrieving, updating, and deleting agents.
 */
@RestController
@RequestMapping("/api/agents") // New base path for agent endpoints
public class AgentController {

    private final AgentService agentService;

    public AgentController(AgentService agentService) {
        this.agentService = agentService;
    }

    /**
     * POST /api/agents : Creates a new agent.
     * @param agentDto The DTO containing agent details.
     * @return ResponseEntity with the created AgentDto and HTTP status CREATED.
     */
    @PostMapping
    public ResponseEntity<AgentDto> createAgent(@Valid @RequestBody AgentDto agentDto) {
        AgentDto createdAgent = agentService.createAgent(agentDto);
        return new ResponseEntity<>(createdAgent, HttpStatus.CREATED);
    }

    /**
     * GET /api/agents/{id} : Retrieves an agent by ID.
     * @param id The ID of the agent to retrieve.
     * @return ResponseEntity with the AgentDto if found, or NOT_FOUND.
     */
    @GetMapping("/{id}")
    public ResponseEntity<AgentDto> getAgentById(@PathVariable Long id) {
        AgentDto agentDto = agentService.getAgentById(id);
        return ResponseEntity.ok(agentDto);
    }

    /**
     * GET /api/agents : Retrieves a list of all agents.
     * @return ResponseEntity with a list of AgentDto and HTTP status OK.
     */
    @GetMapping
    public ResponseEntity<List<AgentDto>> getAllAgents() {
        List<AgentDto> agents = agentService.getAllAgents();
        return ResponseEntity.ok(agents);
    }

    /**
     * PUT /api/agents/{id} : Updates an existing agent.
     * @param id The ID of the agent to update.
     * @param agentDto The DTO with updated agent details.
     * @return ResponseEntity with the updated AgentDto and HTTP status OK.
     */
    @PutMapping("/{id}")
    public ResponseEntity<AgentDto> updateAgent(@PathVariable Long id, @Valid @RequestBody AgentDto agentDto) {
        AgentDto updatedAgent = agentService.updateAgent(id, agentDto);
        return ResponseEntity.ok(updatedAgent);
    }

    /**
     * DELETE /api/agents/{id} : Deletes an agent by ID.
     * @param id The ID of the agent to delete.
     * @return ResponseEntity with HTTP status NO_CONTENT.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAgent(@PathVariable Long id) {
        agentService.deleteAgent(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
