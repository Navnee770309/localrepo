package exception;

import org.springframework.http.HttpStatus;

public class CrmAPIException extends RuntimeException {

    private final HttpStatus status;

    public CrmAPIException(HttpStatus status, String message) {
        super(message);
        this.status = status;
    }

    public HttpStatus getStatus() {
        return status;
    }
}
